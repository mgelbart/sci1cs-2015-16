The running time is O(N+T) which can also be written as O(N) and O(T). The memory usage is actually the same. But, we are neglecting all kinds of things here, such as the dependence on k, etc.
