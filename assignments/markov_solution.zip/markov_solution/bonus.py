import os
import sys
import numpy as np
from collections import defaultdict
from collections import Counter

# create a Markov model of order k from given text
# Assume that text has length at least k.
def count(text, k):
	frequencies = defaultdict(Counter)
	circ_text = text + text[:k]
	for i in xrange(len(text)):
		frequencies[circ_text[i:i+k]][circ_text[i+k]] += 1.0
	return frequencies

# Returns a random character following given kgram
def rand(frequencies, kgram):
	probs = frequencies[kgram].values()
	probs /= np.sum(probs)
	return np.random.choice(frequencies[kgram].keys(), p=probs)

# generate a String of length T characters
# by simulating a trajectory through the corresponding
# Markov chain.  The first k characters of the newly
# generated string should be the argument kgram.
# Assume that T is at least k.
def gen(frequencies, kgram, T):
	k = len(kgram)
	s = kgram
	while len(s) < T:
		s += rand(frequencies, s[-k:] if k>0 else '') # special case if k=0
	return s

def main(k, T, *filenames):
	k = int(k)
	T = int(T)
	
	text = ""
	for filename in filenames: # allows us to read multiple files
		with open(filename) as f:
			text += f.read() + "\n"

	# remove whitespace and replace with a space (not part of the assignment)
	# (but nice because it gets rid of newlines, etc.)
	text = ' '.join(text.split())

	frequencies = count(text, k)

	print gen(frequencies, text[:k], T)

if __name__ == "__main__":
	main(*sys.argv[1:])

