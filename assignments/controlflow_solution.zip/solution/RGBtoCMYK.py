import sys

#read in command line arguments
r=float(sys.argv[1])   #red
g=float(sys.argv[2])   #green
b=float(sys.argv[3])   #blue

if r == 0 and g == 0 and b == 0:
	c = 0.0
	m = 0.0
	y = 0.0
	k = 1.0
else:
	w=max(r/255.0,g/255.0,b/255.0);
	c=(w-r/255.0)/w #cyan
	m=(w-g/255.0)/w #magenta
	y=(w-b/255.0)/w #yellow
	k=(1-w)         #black

print "cyan    = %f" % c;
print "magenta = %f" % m;
print "yellow  = %f" % y;
print "black   = %f" % k;
# above I used a format string. the %f means this is a placeholder
# for a float. you then use the percent sign followed by the float
# you want to insert. these format strings give you a lot of control
# over formatting. for example %.3f means a float printed with 3
# decimal places. use %d for integers and %s for strings.