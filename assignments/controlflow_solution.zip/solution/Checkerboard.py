import sys

N = int(sys.argv[1])

i = 0
while i < N:
	j = 0
	while j < N:
		if i % 2 == 1:
			sys.stdout.write(' *')
		else:
			sys.stdout.write('* ')
		j += 1
	print ''
	i += 1


# Here is another version that doesn't use mod (the percent sign)
"""
i = 0
odd_row = False
while i < N:
	if odd_row:
		sys.stdout.write(' ')
	j = 0
	while j < N:
		sys.stdout.write('* ')
		j += 1
	print ''
	i += 1
	odd_row = not odd_row
"""


# Here is another version that defeats the purpose of the assignment
# (because it doesn't practice using nested loops).
# If you did it this way, that is completely OK, but make sure you understand
# the other solutions above, because you will need nested loops
# going forward in this course.
"""
i = 0
while i < N:
	if i % 2 == 1:
		print '',
	print '* '*N
	i += 1
"""