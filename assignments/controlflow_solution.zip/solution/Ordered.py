import sys

#read in command line arguments
x=float(sys.argv[1])
y=float(sys.argv[2])
z=float(sys.argv[3])

isOrdered=False

#check if x y z are in ascending order:
if x<y and y<z:
	isOrdered=True
        
#check if x y z are in descending order:
if x>y and y>z:
	isOrdered=True

print isOrdered