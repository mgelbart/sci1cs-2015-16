import sys
import random

N = int(sys.argv[1])

x = 0
y = 0

n = 0
while n < N:
	r = random.random()
	if r < 0.25:
		x += 1 # shorthand for x = x + 1
	elif r < 0.5:
		x -= 1 # shorthand for x = x - 1
	elif r < 0.75:
		y += 1 # shorthand for y = y + 1
	else:
		y -= 1 # shorthand for y = y - 1

	print '(%d, %d)' % (x,y) # another use of format strings

	n = n + 1

print 'squared distance = %d' % (x**2 + y**2)
# in Python, a**b means a to the power of b.
# you could have done x*x + y*y instead.