/**********************************************************************
 ***  COS 126  ***   Markov Model of Natural Language  ***  Readme  ***
 **********************************************************************/

Name: 
Login: 
Precept: 

Partner's name (if any):
Partner's email:
Partner's precept:

Which partner is submitting the program files?

Hours to complete assignment (optional): 

/**********************************************************************
 * Describe the type parameters of your symbol table and how you used *
 * the symbol table to implement the rand() method.                   *
 **********************************************************************/



/**********************************************************************
 * The main() method we provide in the checklist does not test your   *
 * rand() or gen() methods. Describe how you tested your rand() and   *
 * gen() methods.                                                     *
 **********************************************************************/



/**********************************************************************
 * Paste two of your favorite, not too long, output fragments here.   *
 * In addition to the pseudo-random text, indicate the order of your  *
 * model and what text file you used.                                 *
 **********************************************************************/



/**********************************************************************
 * If you and/or your partner did the extra credit,                   *
 * please note here who did it (only you, only your partner, both).   *
 **********************************************************************/



/**********************************************************************
 * Did you receive help from classmates, past COS 126 students, or    *
 * anyone else?  Please list their names.  ("A Sunday lab TA" or      *
 * "Office hours on Thursday" is ok if you don't know their name.)    *
 **********************************************************************/



/**********************************************************************
 * Describe any serious problems you encountered.                     *
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     *
 **********************************************************************/

