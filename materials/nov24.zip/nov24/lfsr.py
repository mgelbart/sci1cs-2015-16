import numpy as np
import matplotlib.pyplot as plt
"""
Produces a pseudo-random sequence of bits using a linear feedback shift register.
"""

def step(seed, tap):
	return str(int(seed[tap])^int(seed[0]))

def LFSR(seed, tap, N):
	out = ""
	for n in range(N):
		bit = step(seed, tap)
		out += bit
		seed = seed[1:] + bit
	return out, seed

def bits2int(bits, k=-1):
	N = k if k > 0 else len(bits)
	out = 0
	for n in range(N):
		out += int(bits[n])*2**(N-n-1)
	return out

def rand(tap=2, k=5):
	num = 10
	while num > 9:
		bits, rand.seed = LFSR(rand.seed, tap, k)
		num = bits2int(bits, k)
	return num
rand.seed = "011010001100010"

N_trials = 1000
rands = np.zeros(N_trials)
for i in range(N_trials):
	rands[i] = rand()

print rands 
plt.hist(rands, bins=10, normed=True)
plt.savefig("rand_hist.pdf")