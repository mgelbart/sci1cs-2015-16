# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 11:58:26 2015

@author: mgelbart
"""
import sys

N = float(sys.argv[1])

n = 1
while n <= N:
        
    m = 1
    while m <= N:
        sys.stdout.write(str(m))
        sys.stdout.write("\n")
        m = m + 1
                
    n = n + 1
    
#print 'business as usual'