# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 11:53:40 2015

@author: mgelbart
"""
import sys


x = int(sys.argv[1])


#print 'the value is ' + str(x)

print 'the value is %d' % x

print 'a'
print 'a'
print 'a'
print 'a'
print 'a'
