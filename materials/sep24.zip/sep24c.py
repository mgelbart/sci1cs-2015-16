# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 11:58:26 2015

@author: mgelbart
"""
import sys

N = float(sys.argv[1])

n = 1
while n <= N:
    sys.stdout.write(str(n))
    sys.stdout.write("\n")
    n = n + 1

    
#print 'business as usual'