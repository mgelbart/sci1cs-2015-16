"""
Physics/CS Tutorial Problem 2
Author: Mike Gelbart
Note: this program uses the point-by-point plotting syntax, rather than the (superior) array plotting syntax.
"""
import numpy as np 
import matplotlib.pyplot as plt 

"""
Solves the differential equation representing motion in 2-D with constant acceleration.
Inputs:  x  (float), the initial x-position (m)
         y  (float), the initial y-position (m)
         vx (float), the initial x-velocity (m/s)
         vy (float), the initial y-velocity (m/s)
         ax (float), the (constant) x-acceleration (m/s^2)
         ay (float), the (constant) y-acceleration (m/s^2)
         dt  (float), the time step, in seconds
         make_plot (Boolean), whether or not to plot the points as you simulate them (True=yes, False=no)
Outputs: nothing, but prints the results to the screen instead
         (I did it this way because I haven't yet talked about how to return multiple values)
"""
def solve(x, y, vx, vy, ax, ay, dt, make_plot):
	print 'Using dt=%f' % dt

	t = 0
	while y >= 0:
		if make_plot:
			plt.plot(x,y,'.b')

		x += vx*dt
		y += vy*dt
		vx += ax*dt
		vy += ay*dt
		t += dt
	
	print 'The object was in the air for %f seconds' % t
	print 'The object traveled a horizontal distance of %f metres' % x

print '+------------+'
print '|  Part (a)  |'
print '+------------+'
x_0 = 0.0    # m
y_0 = 0.0    # m
vx_0 = 10.0  # m/s
vy_0 = 10.0  # m/s

ax = 0.0   # m/s^2
ay = -9.8  # m/s^2

solve(x_0, y_0, vx_0, vy_0, ax, ay, 0.1, False)

print '+------------+'
print '|  Part (b)  |'
print '+------------+'
time_in_air = (-2*vy_0/ay)
print 'Exact time spent in air: %f' % time_in_air
print 'Exact horizontal distance traveled: %f' % (vx_0*time_in_air)


print '+------------+'
print '|  Part (c)  |'
print '+------------+'
solve(x_0, y_0, vx_0, vy_0, ax, ay, 0.01, False)


print '+------------+'
print '|  Part (d)  |'
print '+------------+'
solve(x_0, y_0, vx_0, vy_0, ax, ay, 0.01, True)
plt.xlabel('x (metres)')
plt.ylabel('y (metres)')
plt.title('An object moving subject to gravity only (Problem 2)')
plt.savefig('constant_accel.pdf')
print 'Saved plot in constant_accel.pdf'