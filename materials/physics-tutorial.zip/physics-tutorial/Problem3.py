"""
Physics/CS Tutorial Problem 3
Author: Mike Gelbart
Note: this program uses the point-by-point plotting syntax, rather than the (superior) array plotting syntax.
"""
import numpy as np 
import matplotlib.pyplot as plt 

"""
Solves the differential equation representing motion in 2-D subject to gravity and air drag.
Inputs:  x    (float), the initial x-position (m)
         y    (float), the initial y-position (m)
         vx   (float), the initial x-velocity (m/s)
         vy   (float), the initial y-velocity (m/s)
         drag (float), the drag coefficient (kg/m)
         dt   (float), the time step, in seconds
         make_plot (Boolean), whether or not to plot the points as you simulate them (True=yes, False=no)
Outputs: the horizontal distance traveled before hitting the ground (m)
"""
def solve(x, y, vx, vy, drag, dt, make_plot):

	g = 9.8 # m/s^2
	t = 0
	while y >= 0:

		if make_plot:
			plt.plot(x,y,'.b')

		x += vx*dt
		y += vy*dt

		v = np.sqrt(vx*vx + vy*vy)
		ax = -drag*vx*v
		ay = -drag*vy*v-g

		vx += ax*dt
		vy += ay*dt
		
		t += dt
	
	return x

x_0 = 0.0    # m
y_0 = 100.0  # m
vx_0 = 10.0  # m/s
vy_0 = 0.0   # m/s
drag = 0.155 # kg/m
x_drop = solve(x_0, y_0, vx_0, vy_0, drag, 0.1, True)
print 'The object should be dropped %.2f metres from the clearing.' % x_drop

plt.xlabel('x (metres)')
plt.ylabel('y (metres)')
plt.title('Object dropped from an airplane subject to drag (Problem 3)')
plt.savefig('air_drag.pdf')
print 'Saved plot in air_drag.pdf'