"""
Physics/CS Tutorial Problem 4
Author: Mike Gelbart
Note: this program uses the point-by-point plotting syntax, rather than the (superior) array plotting syntax.
"""
import numpy as np 
import matplotlib.pyplot as plt 

"""
Solves the differential equation representing motion in 2-D subject to gravity and air drag.
Inputs:  x    (float), the initial x-position (m)
         y    (float), the initial y-position (m)
         vx   (float), the initial x-velocity (m/s)
         vy   (float), the initial y-velocity (m/s)
         drag (float), the drag coefficient (kg/m)
         dt   (float), the time step, in seconds
         make_plot (Boolean), whether or not to plot the points as you simulate them (True=yes, False=no)
Outputs: the horizontal distance traveled before hitting the ground (m)
"""
def solve(x, y, vx, vy, drag, dt, make_plot):

	g = 9.8 # m/s^2
	t = 0
	while x <= 0 and y >= 0: # exit if you hit the wall OR hit the ground
		
		if make_plot:
			plt.plot(x,y,'.b')

		x += vx*dt
		y += vy*dt

		v = np.sqrt(vx*vx + vy*vy)
		ax = -drag*vx*v
		ay = -drag*vy*v-g
		
		vx += ax*dt
		vy += ay*dt
			
		t += dt
	
	# make sure we don't return a negative value
	if y < 0:
		return 0.0
	else:
		return y


v_0 = 47.0 # m/s
x_0 = -97.0 # m (assume the Green Monster is at x=0)
y_0 = 1.0 # m
drag = 0.00805 # kg/m
dt = 0.005 # s
green_monster_height = 11.3 # m

best_height = 0
best_angle = 0

# test out all angles from angle to max_angle with a step size of angle_step
angle = 0
max_angle = 90
angle_step = 0.1

while angle < max_angle:
	angle_radians = angle*(np.pi/180.0)
	vx_0 = v_0*np.cos(angle_radians)
	vy_0 = v_0*np.sin(angle_radians)

	y_final = solve(x_0, y_0, vx_0, vy_0, drag, dt, False)
	plt.plot(angle, y_final, '.b')

	if y_final > best_height:
		best_height = y_final
		best_angle = angle

	angle += angle_step

	# print "With an angle of %f degrees, Chris's ball reaches %f meters when it hits the wall" % (angle, y_final)

print "The best angle is %.1f degrees. In this case, the ball reaches %f meters when it hits the wall." % (best_angle, best_height)

if best_height >= green_monster_height:
	print 'So... David Ortiz *CAN* hit a home run over the Green Monster.'
else:
	print 'So... David Ortiz can *NOT* hit a home run over the Green Monster.'

# plot a dashed line at green_monster_height (you don't need to know how to do this)
plt.plot([0, 90], [green_monster_height, green_monster_height], '--g')

plt.xlabel('angle (degrees)')
plt.ylabel('ball height (metres)')
plt.title('Baseball subject to drag (Problem 4)')
plt.savefig('baseball.pdf')
print 'Saved plot in basball.pdf'