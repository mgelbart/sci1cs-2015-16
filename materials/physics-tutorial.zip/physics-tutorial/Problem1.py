"""
Physics/CS Tutorial Problem 1
Author: Mike Gelbart
Note: this program uses the point-by-point plotting syntax, rather than the (superior) array plotting syntax. 
"""
import numpy as np 
import matplotlib.pyplot as plt 

"""
Solves the differential equation representing the decay of Aaaagh using the Euler method.
Inputs:  A_0 (float), the initial quantity of Aaaagh, in grams
         T   (float), the amount of time to simulate, in seconds
         dt  (float), the time step, in seconds
         make_plot (Boolean), whether or not to plot the points as you simulate them (True=yes, False=no)
Outputs: the quantity of Aaaagh at time T (float)
"""
def solve(A_0, T, dt, make_plot):
	A = A_0
	t = 0
	while t < T:
		if make_plot:
			plt.plot(t,A, '.b')
		A = A - 0.7*A*dt
		t += dt
	return A

print '+------------+'
print '|  Part (a)  |'
print '+------------+'
A_0 = 43.0 # initial Aaaagh (grams)
T   = 5.0  # total time (seconds)
print 'My solution using the Euler method: %f' % solve(A_0, T, 0.01, False)


print '+------------+'
print '|  Part (b)  |'
print '+------------+'
dt = 0.1
for i in range(4):
	print 'The solution with dt=%f is %f' % (dt, solve(A_0, T, dt, False))
	dt = dt * 0.1


print '+------------+'
print '|  Part (c)  |'
print '+------------+'
solve(A_0, T, 0.01, True)
plt.xlabel('Time (seconds)')
plt.ylabel('Aaaagh (grams)')
plt.title('Concentration of Aaaagh over time (Problem 1)')
plt.savefig('Aaaagh.pdf')
print 'Saved plot in Aaaagh.pdf'

print '+------------+'
print '|  Part (d)  |'
print '+------------+'
print 'This is an exponential function. The solution is A(t) = A_0 exp(-0.7t)'
print 'The true amount of Aaaagh at T=5: %f' % (A_0*np.exp(-0.7*T)) 
print 'Note that the results in part (b) approach this true value as dt gets smaller.'