# -*- coding: utf-8 -*-
"""
Name: Mike Gelbart
UBC student number: 32432489329
"""
import sys 


x = int(sys.argv[1])
y = int(sys.argv[2])

#print x_is_negative
print  x
print  y

if x < 0:
    print "x is negative"
else:
    if x == 0:
        print "x is zero"
    else:
        print "x is positive"
