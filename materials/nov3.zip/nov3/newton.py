# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 11:24:46 2015

@author: Mike
"""
import numpy as np

def f(x):
    #return np.exp(x)-1.5
    print 'hello'
    the_answer = 0.01*x**2 -np.sin(x)
    another_var = 99999
    return the_answer
def fprime(x):
    #return np.exp(x)
    return 0.02*x - np.cos(x)

def optimize(x, N):
    for n in range(N):
        x = x - f(x)/fprime(x)
        print x
        print n
    N = 99999
    return x

N = 10
optimize(2, N)