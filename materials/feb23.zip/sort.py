import matplotlib.pyplot as plt
import numpy as np
import time

def swap(x,i,j):
	temp = x[j]
	x[j] = x[i]
	x[i] = temp
	
def my_sort(x):
	for i in range(len(x)):
		for j in range(i+1,len(x)):
			if x[j] < x[i]:
				swap(x,i,j)
	# return x

Nvals = range(25,1000,25)
my_times = list()
py_times = list()

for N in Nvals:
	print N
	z = np.random.rand(N)

	start_time = time.time()
	z_sort = sorted(z)
	py_times.append(time.time()-start_time)

	start_time = time.time()
	my_sort(z)
	my_times.append(time.time()-start_time)

	assert np.array_equal(z_sort, z)

plt.plot(Nvals, my_times)
plt.plot(Nvals, py_times, 'r')
plt.legend(('mine', 'builtin'), loc='upper left')
plt.xlabel('array size')
plt.ylabel('sorting time (seconds)')
plt.savefig('times.pdf')

plt.cla()
plt.plot(Nvals, py_times, 'r')
plt.ylabel('sorting time (seconds)')
plt.savefig('times_py_only.pdf')

plt.cla()
plt.loglog(Nvals, my_times)
plt.loglog(Nvals, py_times, 'r')
plt.legend(('mine', 'builtin'), loc='upper left')
plt.ylabel('sorting time (seconds)')
plt.savefig('times_loglog.pdf')
