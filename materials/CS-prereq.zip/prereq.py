from graphviz import Digraph
import json

CPSC_COURSES_ONLY = True
styles = {"pre" : None, "co": "dashed"}

with open("UBC_CPSC.json") as f:
	courses = json.load(f)

if CPSC_COURSES_ONLY: # filter out non-CPSC courses
	for course in courses:
		for reqs_AND in courses[course].values():
			for i in xrange(len(reqs_AND)):
				reqs_AND[i] = filter(lambda x: x[:4]=="CPSC", reqs_AND[i])

dot = Digraph(comment='UBC CPSC')

for course in courses:
	dot.node(course, course)

for course, data in courses.iteritems():
	for req_type, prereqs_CNF in data.iteritems(): # pre, co-requisites
		for i,prereqs_AND in enumerate(prereqs_CNF):

			if len(prereqs_AND) > 1:
				node2 = '%s%d' % (course,i)
				dot.node(node2, "or")
				dot.edge(node2, course)
			else:
				node2 = course

			for prereq_OR in prereqs_AND:
				dot.edge(prereq_OR, node2, style=styles[req_type])

dot.render('UBC_CPSC_prereq.gv', view=True)