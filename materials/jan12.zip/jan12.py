# -*- coding: utf-8 -*-
"""
Created on Tue Jan 12 11:27:31 2016

@author: mgelbart
"""
import numpy as np

# creates pascal's triangle
def pascal(n):
    x = np.zeros((n,n), dtype=int)
    x[0,:] = 1
    x[:,0] = 1
    
    for i in range(1,n):
        for j in range(1,n):
            x[i,j] = x[i-1,j] + x[i,j-1]
    
    return x

print pascal(5)