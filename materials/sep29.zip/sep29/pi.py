import matplotlib.pyplot as plt
import random

N = 1000
num_in_circle = 0

i = 0
while i < N:
	x = random.random()
	y = random.random()
	
	if (x-0.5)**2+(y-0.5)**2 <= 0.5**2:
		num_in_circle += 1
		plt.plot(x,y,'.r')
	else:
		plt.plot(x,y,'.b')

	i += 1

print 'Number of points in circle: %d out of %d' % (num_in_circle, N)
print 'Fraction of points in circle: %f' % (num_in_circle/float(N))
print 'Estimate of pi: %f' % (num_in_circle/float(N)/0.5/0.5)

plt.axis('equal')
plt.savefig('pi.pdf')