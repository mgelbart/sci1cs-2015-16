# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 11:58:26 2015

@author: mgelbart
"""
import matplotlib.pyplot as plt
import random
import math

N = 1000

n = 1
while n <= N:
    x = random.random()
    y = random.random()

    dist_squared = (x-0.5)*(x-0.5) + (y-0.5)*(y-0.5)
    dist = math.sqrt(dist_squared)

    if dist < 0.5:
        plt.plot(x,y,'.r')
    else:
        plt.plot(x,y,'.b')
    n = n + 1


plt.show()