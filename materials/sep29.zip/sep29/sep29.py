# -*- coding: utf-8 -*-
"""
Author: Mike Gelbart


"""
import matplotlib.pyplot as plt
import random

x = random.random() # this gives me a random float between 0 and 1

plt.plot(x, 1, '.b')

#plt.show()
plt.savefig('hello.pdf')