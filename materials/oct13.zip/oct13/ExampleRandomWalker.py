import sys
import random

N = int(sys.argv[1])


x = 0
y = 0

n = random.random()

count = 0 

while count < N:
    if n<0.25 and n>0:
        x = x + 1
        print (x,y)
        count = count + 1
        n = random.random()
    if n<0.5 and n>0.25:
        x = x - 1
        print (x,y)
        count = count + 1
        n = random.random()
    if n<0.75 and n>0.5:
        y = y + 1
        print (x,y)
        count = count + 1
        n = random.random()
    if n<1 and n>0.75:
        y = y - 1
        print (x,y)
        count = count + 1
        n = random.random()

s = x*x + y*y
print "squared distance = " + str(s)

    
    
    
    
    
