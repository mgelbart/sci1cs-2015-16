# -*- coding: utf-8 -*-
"""
Created on Tue Oct 13 12:13:26 2015

@author: mgelbart
"""

def add_one(a):
    b= a + 1
    c = "hello"
    d = "science one!"
    e = 5.55555
    return b

x = 0
for i in range(10):
    x = add_one(x)
    
print x